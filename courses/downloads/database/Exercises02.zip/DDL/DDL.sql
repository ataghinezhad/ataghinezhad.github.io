-- 1. جدول اساتید (Faculty)

CREATE TABLE Faculty (
    fid    INT PRIMARY KEY,          
    fname  VARCHAR(50) NOT NULL,      
    deptid INT                        
);

-- 2. جدول دانشجویان (Student)
CREATE TABLE Student (
    snum   INT PRIMARY KEY,          
    sname  VARCHAR(50) NOT NULL,     
    major  VARCHAR(50),               
    level  CHAR(2),                  
    age    INT,                      
    
  
    CONSTRAINT CHK_Level CHECK (level IN ('FR', 'SO', 'JR', 'SR', 'GR')),
    CONSTRAINT CHK_Age CHECK (age > 15 AND age < 100)
);

-- 3. جدول کلاس‌ها (Class)
CREATE TABLE Class (
    name      VARCHAR(100) PRIMARY KEY,
    meets_at  VARCHAR(50),              
    room      VARCHAR(20),             
    fid       INT,                      
    
    CONSTRAINT FK_Class_Faculty FOREIGN KEY (fid) 
        REFERENCES Faculty(fid) 
        ON DELETE SET NULL
);

-- 4. جدول ثبت‌نام (Enrolled)
CREATE TABLE Enrolled (
    snum  INT,                        
    cname VARCHAR(100),               
    
    PRIMARY KEY (snum, cname),     
    

    CONSTRAINT FK_Enrolled_Student FOREIGN KEY (snum) 
        REFERENCES Student(snum) 
        ON DELETE CASCADE,
        
    CONSTRAINT FK_Enrolled_Class FOREIGN KEY (cname) 
        REFERENCES Class(name) 
        ON DELETE CASCADE
);